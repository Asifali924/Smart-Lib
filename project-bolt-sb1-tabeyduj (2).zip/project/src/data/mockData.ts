import { Library, Seat, Book, Event } from '../types';

export const mockLibraries: Library[] = [
  {
    id: 'lib-1',
    name: 'ICAP Main Library',
    address: 'Shaheed-e-Millat Rd, Karachi',
    coordinates: { lat: 24.8607, lng: 67.0011 },
    totalSeats: 150,
    availableSeats: 45,
    openingHours: '8:00 AM - 10:00 PM',
    facilities: ['WiFi', 'AC', 'Printing', 'Cafe', 'Study Rooms'],
    isActive: true,
    capacity: 150,
    currentOccupancy: 105,
    adminId: 'admin-1'
  },
  {
    id: 'lib-2',
    name: 'ICAP North Campus Library',
    address: 'North Nazimabad, Karachi',
    coordinates: { lat: 24.9207, lng: 67.0311 },
    totalSeats: 100,
    availableSeats: 32,
    openingHours: '9:00 AM - 9:00 PM',
    facilities: ['WiFi', 'AC', 'Group Study', 'Digital Lab'],
    isActive: true,
    capacity: 100,
    currentOccupancy: 68,
    adminId: 'admin-1'
  },
  {
    id: 'lib-3',
    name: 'ICAP Executive Library',
    address: 'Clifton Block 5, Karachi',
    coordinates: { lat: 24.8138, lng: 67.0299 },
    totalSeats: 80,
    availableSeats: 18,
    openingHours: '7:00 AM - 11:00 PM',
    facilities: ['WiFi', 'AC', 'Premium Seating', 'Coffee Bar', 'Silent Zone'],
    isActive: true,
    capacity: 80,
    currentOccupancy: 62
  }
];

export const mockSeats: Seat[] = [
  // Main Library Seats
  { 
    id: 'seat-1', 
    libraryId: 'lib-1', 
    seatNumber: 'A01', 
    status: 'available', 
    position: { x: 50, y: 50 }, 
    type: 'regular', 
    amenities: ['Power Outlet'], 
    qrCode: 'QR-A01' 
  },
  { 
    id: 'seat-2', 
    libraryId: 'lib-1', 
    seatNumber: 'A02', 
    status: 'booked', 
    position: { x: 100, y: 50 }, 
    type: 'regular', 
    amenities: ['Power Outlet'], 
    qrCode: 'QR-A02',
    currentBookingId: 'booking-1'
  },
  { 
    id: 'seat-3', 
    libraryId: 'lib-1', 
    seatNumber: 'A03', 
    status: 'available', 
    position: { x: 150, y: 50 }, 
    type: 'premium', 
    amenities: ['Power Outlet', 'Reading Light'], 
    qrCode: 'QR-A03' 
  },
  { 
    id: 'seat-4', 
    libraryId: 'lib-1', 
    seatNumber: 'B01', 
    status: 'occupied', 
    position: { x: 50, y: 100 }, 
    type: 'regular', 
    amenities: ['Power Outlet'], 
    qrCode: 'QR-B01' 
  },
  { 
    id: 'seat-5', 
    libraryId: 'lib-1', 
    seatNumber: 'B02', 
    status: 'free_soon', 
    position: { x: 100, y: 100 }, 
    type: 'group', 
    amenities: ['Power Outlet', 'Whiteboard'], 
    qrCode: 'QR-B02',
    nextAvailableTime: new Date(Date.now() + 25 * 60 * 1000).toISOString() // 25 minutes from now
  },
  { 
    id: 'seat-6', 
    libraryId: 'lib-1', 
    seatNumber: 'B03', 
    status: 'available', 
    position: { x: 150, y: 100 }, 
    type: 'regular', 
    amenities: ['Power Outlet'], 
    qrCode: 'QR-B03' 
  },
  { 
    id: 'seat-7', 
    libraryId: 'lib-1', 
    seatNumber: 'C01', 
    status: 'maintenance', 
    position: { x: 50, y: 150 }, 
    type: 'regular', 
    amenities: ['Power Outlet'], 
    qrCode: 'QR-C01' 
  },
  { 
    id: 'seat-8', 
    libraryId: 'lib-1', 
    seatNumber: 'C02', 
    status: 'available', 
    position: { x: 100, y: 150 }, 
    type: 'premium', 
    amenities: ['Power Outlet', 'Reading Light', 'Privacy Screen'], 
    qrCode: 'QR-C02' 
  },
];

export const mockBooks: Book[] = [
  {
    id: 'book-1',
    title: 'Financial Accounting Principles',
    author: 'Dr. Muhammad Aslam',
    isbn: '978-0-123456-78-9',
    type: 'physical',
    category: 'Accounting',
    cover: 'https://images.pexels.com/photos/159866/books-book-pages-read-literature-159866.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'Comprehensive guide to financial accounting principles and practices for CA students.',
    availability: 'available',
    libraryId: 'lib-1',
    location: 'Section A - Shelf 12',
    uploadedBy: 'admin-1',
    uploadDate: '2024-01-15',
    downloadCount: 0
  },
  {
    id: 'book-2',
    title: 'Advanced Auditing Techniques',
    author: 'Sarah Ahmed',
    isbn: '978-0-987654-32-1',
    type: 'digital',
    category: 'Auditing',
    cover: 'https://images.pexels.com/photos/1170412/pexels-photo-1170412.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'Modern auditing techniques and best practices for CA students and professionals.',
    availability: 'available',
    digitalAccess: {
      subscriptionRequired: true,
      passphrase: 'AUDIT2024',
      pdfUrl: '/books/advanced-auditing.pdf',
      accessLevel: 'premium'
    },
    uploadedBy: 'admin-1',
    uploadDate: '2024-01-20',
    downloadCount: 156
  },
  {
    id: 'book-3',
    title: 'Corporate Finance Management',
    author: 'Ali Hassan Khan',
    isbn: '978-0-456789-01-2',
    type: 'physical',
    category: 'Finance',
    cover: 'https://images.pexels.com/photos/1907785/pexels-photo-1907785.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'Essential concepts in corporate finance and investment decisions.',
    availability: 'reserved',
    libraryId: 'lib-1',
    location: 'Section B - Shelf 8',
    uploadedBy: 'admin-1',
    uploadDate: '2024-01-10',
    downloadCount: 0
  },
  {
    id: 'book-4',
    title: 'Taxation Laws in Pakistan',
    author: 'Fatima Sheikh',
    isbn: '978-0-234567-89-0',
    type: 'digital',
    category: 'Taxation',
    cover: 'https://images.pexels.com/photos/590016/pexels-photo-590016.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'Complete guide to Pakistan taxation laws and regulations for CA students.',
    availability: 'available',
    digitalAccess: {
      subscriptionRequired: false,
      pdfUrl: '/books/taxation-laws.pdf',
      accessLevel: 'free'
    },
    uploadedBy: 'admin-1',
    uploadDate: '2024-02-01',
    downloadCount: 89
  },
  {
    id: 'book-5',
    title: 'Business Law Fundamentals',
    author: 'Ahmed Malik',
    isbn: '978-0-345678-90-1',
    type: 'digital',
    category: 'Law',
    cover: 'https://images.pexels.com/photos/1181533/pexels-photo-1181533.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'Fundamental concepts of business law for accounting professionals.',
    availability: 'available',
    digitalAccess: {
      subscriptionRequired: true,
      passphrase: 'LAW2024',
      pdfUrl: '/books/business-law.pdf',
      accessLevel: 'premium_plus'
    },
    uploadedBy: 'admin-1',
    uploadDate: '2024-01-25',
    downloadCount: 234
  }
];

export const mockEvents: Event[] = [
  {
    id: 'event-1',
    title: 'CA Exam Preparation Workshop',
    description: 'Intensive workshop covering key topics for upcoming CA examinations with expert faculty.',
    date: '2024-02-15',
    startTime: '10:00',
    endTime: '16:00',
    venue: 'ICAP Main Library - Conference Hall',
    capacity: 50,
    registered: 32,
    waitlist: 5,
    type: 'workshop',
    isPaid: true,
    price: 2000,
    image: 'https://images.pexels.com/photos/1181533/pexels-photo-1181533.jpeg?auto=compress&cs=tinysrgb&w=600',
    organizerId: 'admin-1',
    registrationDeadline: '2024-02-13',
    isActive: true
  },
  {
    id: 'event-2',
    title: 'Digital Accounting Seminar',
    description: 'Learn about modern digital accounting tools and software used in the industry.',
    date: '2024-02-20',
    startTime: '14:00',
    endTime: '17:00',
    venue: 'ICAP North Campus - Auditorium',
    capacity: 100,
    registered: 78,
    waitlist: 12,
    type: 'seminar',
    isPaid: false,
    image: 'https://images.pexels.com/photos/1181677/pexels-photo-1181677.jpeg?auto=compress&cs=tinysrgb&w=600',
    organizerId: 'admin-1',
    registrationDeadline: '2024-02-18',
    isActive: true
  },
  {
    id: 'event-3',
    title: 'Study Group - Financial Reporting',
    description: 'Collaborative study session for Financial Reporting standards and practices.',
    date: '2024-02-12',
    startTime: '18:00',
    endTime: '20:00',
    venue: 'ICAP Executive Library - Study Room 2',
    capacity: 15,
    registered: 12,
    waitlist: 3,
    type: 'study_group',
    isPaid: false,
    image: 'https://images.pexels.com/photos/1181406/pexels-photo-1181406.jpeg?auto=compress&cs=tinysrgb&w=600',
    organizerId: 'admin-1',
    registrationDeadline: '2024-02-11',
    isActive: true
  },
  {
    id: 'event-4',
    title: 'Advanced Excel for Accountants',
    description: 'Master advanced Excel techniques specifically designed for accounting professionals.',
    date: '2024-02-25',
    startTime: '09:00',
    endTime: '17:00',
    venue: 'ICAP Main Library - Computer Lab',
    capacity: 25,
    registered: 18,
    waitlist: 7,
    type: 'workshop',
    isPaid: true,
    price: 1500,
    image: 'https://images.pexels.com/photos/1181244/pexels-photo-1181244.jpeg?auto=compress&cs=tinysrgb&w=600',
    organizerId: 'admin-1',
    registrationDeadline: '2024-02-23',
    isActive: true
  }
];