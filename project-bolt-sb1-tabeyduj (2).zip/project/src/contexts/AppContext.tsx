import React, { createContext, useContext, useState, useEffect } from 'react';
import { Library, Seat, Book, Booking, Event, Reservation, Analytics, AIRecommendation, Payment } from '../types';
import { mockLibraries, mockSeats, mockBooks, mockEvents } from '../data/mockData';

interface AppContextType {
  libraries: Library[];
  seats: Seat[];
  books: Book[];
  events: Event[];
  bookings: Booking[];
  reservations: Reservation[];
  analytics: Analytics[];
  recommendations: AIRecommendation[];
  payments: Payment[];
  selectedLibrary: Library | null;
  setSelectedLibrary: (library: Library | null) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  addBooking: (booking: Omit<Booking, 'id'>) => void;
  addReservation: (reservation: Omit<Reservation, 'id'>) => void;
  updateSeatStatus: (seatId: string, status: Seat['status']) => void;
  checkInSeat: (bookingId: string, qrCode: string) => Promise<boolean>;
  checkOutSeat: (bookingId: string) => Promise<boolean>;
  autoReleaseExpiredBookings: () => void;
  generateAIRecommendations: (userId: string) => AIRecommendation[];
  addLibrary: (library: Omit<Library, 'id'>) => void;
  updateLibrary: (libraryId: string, updates: Partial<Library>) => void;
  addBook: (book: Omit<Book, 'id'>) => void;
  updateBook: (bookId: string, updates: Partial<Book>) => void;
  approveUser: (userId: string) => void;
  getLibraryAnalytics: (libraryId: string) => Analytics | null;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [libraries, setLibraries] = useState<Library[]>(mockLibraries);
  const [seats, setSeats] = useState<Seat[]>(mockSeats);
  const [books, setBooks] = useState<Book[]>(mockBooks);
  const [events, setEvents] = useState<Event[]>(mockEvents);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [analytics, setAnalytics] = useState<Analytics[]>([]);
  const [recommendations, setRecommendations] = useState<AIRecommendation[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [selectedLibrary, setSelectedLibrary] = useState<Library | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  // Auto-release expired bookings every minute
  useEffect(() => {
    const interval = setInterval(autoReleaseExpiredBookings, 60000);
    return () => clearInterval(interval);
  }, []);

  const addBooking = (booking: Omit<Booking, 'id'>) => {
    const newBooking: Booking = {
      ...booking,
      id: Date.now().toString(),
      autoReleaseTime: new Date(Date.now() + 30 * 60 * 1000).toISOString(), // 30 min auto-release
    };
    setBookings(prev => [...prev, newBooking]);
    updateSeatStatus(booking.seatId, 'booked');
    
    // Update library occupancy
    setLibraries(prev => prev.map(lib => 
      lib.id === booking.libraryId 
        ? { ...lib, availableSeats: lib.availableSeats - 1, currentOccupancy: lib.currentOccupancy + 1 }
        : lib
    ));
  };

  const addReservation = (reservation: Omit<Reservation, 'id'>) => {
    const newReservation: Reservation = {
      ...reservation,
      id: Date.now().toString(),
      pickupDeadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // 7 days
      renewalCount: 0
    };
    setReservations(prev => [...prev, newReservation]);
    
    // Update book availability
    setBooks(prev => prev.map(book => 
      book.id === reservation.bookId 
        ? { ...book, availability: 'reserved' }
        : book
    ));
  };

  const updateSeatStatus = (seatId: string, status: Seat['status']) => {
    setSeats(prev => prev.map(seat => 
      seat.id === seatId ? { ...seat, status } : seat
    ));
  };

  const checkInSeat = async (bookingId: string, qrCode: string): Promise<boolean> => {
    const booking = bookings.find(b => b.id === bookingId);
    const seat = seats.find(s => s.qrCode === qrCode);
    
    if (!booking || !seat || booking.seatId !== seat.id) {
      return false;
    }

    // Update booking status
    setBookings(prev => prev.map(b => 
      b.id === bookingId 
        ? { ...b, checkedIn: true, checkedInAt: new Date().toISOString(), status: 'active' }
        : b
    ));

    // Update seat status
    updateSeatStatus(seat.id, 'occupied');
    
    return true;
  };

  const checkOutSeat = async (bookingId: string): Promise<boolean> => {
    const booking = bookings.find(b => b.id === bookingId);
    if (!booking) return false;

    // Update booking status
    setBookings(prev => prev.map(b => 
      b.id === bookingId 
        ? { 
            ...b, 
            checkedOutAt: new Date().toISOString(), 
            status: 'completed',
            loyaltyPointsEarned: 10 // Award loyalty points
          }
        : b
    ));

    // Update seat status
    updateSeatStatus(booking.seatId, 'available');
    
    // Update library occupancy
    setLibraries(prev => prev.map(lib => 
      lib.id === booking.libraryId 
        ? { ...lib, availableSeats: lib.availableSeats + 1, currentOccupancy: lib.currentOccupancy - 1 }
        : lib
    ));

    return true;
  };

  const autoReleaseExpiredBookings = () => {
    const now = new Date();
    
    setBookings(prev => prev.map(booking => {
      // Auto-release if not checked in within 30 minutes
      if (
        booking.status === 'upcoming' && 
        !booking.checkedIn && 
        booking.autoReleaseTime && 
        new Date(booking.autoReleaseTime) < now
      ) {
        // Release the seat
        updateSeatStatus(booking.seatId, 'available');
        
        // Update library occupancy
        setLibraries(prevLibs => prevLibs.map(lib => 
          lib.id === booking.libraryId 
            ? { ...lib, availableSeats: lib.availableSeats + 1 }
            : lib
        ));

        return { ...booking, status: 'no_show' as const };
      }
      
      // Auto-complete if session time has ended
      if (
        booking.status === 'active' && 
        booking.checkedIn
      ) {
        const endTime = new Date(`${booking.date}T${booking.endTime}`);
        if (endTime < now) {
          updateSeatStatus(booking.seatId, 'available');
          
          setLibraries(prevLibs => prevLibs.map(lib => 
            lib.id === booking.libraryId 
              ? { ...lib, availableSeats: lib.availableSeats + 1, currentOccupancy: lib.currentOccupancy - 1 }
              : lib
          ));

          return { 
            ...booking, 
            status: 'completed' as const,
            checkedOutAt: endTime.toISOString(),
            loyaltyPointsEarned: 10
          };
        }
      }
      
      return booking;
    }));

    // Update seats that will be free soon
    setSeats(prev => prev.map(seat => {
      const activeBooKing = bookings.find(b => 
        b.seatId === seat.id && 
        b.status === 'active' && 
        b.checkedIn
      );
      
      if (activeBooKing) {
        const endTime = new Date(`${activeBooKing.date}T${activeBooKing.endTime}`);
        const thirtyMinutesFromNow = new Date(now.getTime() + 30 * 60 * 1000);
        
        if (endTime <= thirtyMinutesFromNow && endTime > now) {
          return { 
            ...seat, 
            status: 'free_soon' as const,
            nextAvailableTime: endTime.toISOString()
          };
        }
      }
      
      return seat;
    }));
  };

  const generateAIRecommendations = (userId: string): AIRecommendation[] => {
    const userBookings = bookings.filter(b => b.userId === userId);
    const recommendations: AIRecommendation[] = [];

    // Recommend best time slots based on history
    if (userBookings.length > 0) {
      const popularTimes = userBookings.reduce((acc, booking) => {
        const hour = parseInt(booking.startTime.split(':')[0]);
        acc[hour] = (acc[hour] || 0) + 1;
        return acc;
      }, {} as Record<number, number>);

      const bestTime = Object.entries(popularTimes)
        .sort(([,a], [,b]) => b - a)[0];

      if (bestTime) {
        recommendations.push({
          id: `rec-time-${Date.now()}`,
          userId,
          type: 'time_slot',
          title: 'Your Preferred Time Slot',
          description: `Based on your history, you prefer booking at ${bestTime[0]}:00. A seat is available today!`,
          confidence: 0.8,
          data: { recommendedTime: `${bestTime[0]}:00` },
          isActive: true,
          createdAt: new Date().toISOString()
        });
      }
    }

    // Recommend seats that will be free soon
    const soonToBeFreeSeat = seats.find(s => s.status === 'free_soon');
    if (soonToBeFreeSeat) {
      recommendations.push({
        id: `rec-seat-${Date.now()}`,
        userId,
        type: 'seat',
        title: 'Seat Available Soon',
        description: `Seat ${soonToBeFreeSeat.seatNumber} will be free at ${soonToBeFreeSeat.nextAvailableTime}`,
        confidence: 0.9,
        data: { seatId: soonToBeFreeSeat.id },
        isActive: true,
        createdAt: new Date().toISOString()
      });
    }

    return recommendations;
  };

  const addLibrary = (library: Omit<Library, 'id'>) => {
    const newLibrary: Library = {
      ...library,
      id: Date.now().toString(),
      isActive: true,
      currentOccupancy: 0
    };
    setLibraries(prev => [...prev, newLibrary]);
  };

  const updateLibrary = (libraryId: string, updates: Partial<Library>) => {
    setLibraries(prev => prev.map(lib => 
      lib.id === libraryId ? { ...lib, ...updates } : lib
    ));
  };

  const addBook = (book: Omit<Book, 'id'>) => {
    const newBook: Book = {
      ...book,
      id: Date.now().toString(),
      uploadDate: new Date().toISOString(),
      downloadCount: 0
    };
    setBooks(prev => [...prev, newBook]);
  };

  const updateBook = (bookId: string, updates: Partial<Book>) => {
    setBooks(prev => prev.map(book => 
      book.id === bookId ? { ...book, ...updates } : book
    ));
  };

  const approveUser = (userId: string) => {
    // This would typically update the user in the database
    console.log(`Approving user ${userId}`);
  };

  const getLibraryAnalytics = (libraryId: string): Analytics | null => {
    return analytics.find(a => a.libraryId === libraryId) || null;
  };

  return (
    <AppContext.Provider value={{
      libraries,
      seats,
      books,
      events,
      bookings,
      reservations,
      analytics,
      recommendations,
      payments,
      selectedLibrary,
      setSelectedLibrary,
      searchQuery,
      setSearchQuery,
      addBooking,
      addReservation,
      updateSeatStatus,
      checkInSeat,
      checkOutSeat,
      autoReleaseExpiredBookings,
      generateAIRecommendations,
      addLibrary,
      updateLibrary,
      addBook,
      updateBook,
      approveUser,
      getLibraryAnalytics
    }}>
      {children}
    </AppContext.Provider>
  );
};