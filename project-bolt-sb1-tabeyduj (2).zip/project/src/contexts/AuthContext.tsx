import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Notification } from '../types';

interface AuthContextType {
  user: User | null;
  login: (crn: string, password: string) => Promise<boolean>;
  register: (userData: Partial<User> & { password: string }) => Promise<boolean>;
  logout: () => void;
  isLoading: boolean;
  updateUser: (userData: Partial<User>) => void;
  notifications: Notification[];
  markNotificationAsRead: (notificationId: string) => void;
  unreadCount: number;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [notifications, setNotifications] = useState<Notification[]>([]);

  useEffect(() => {
    // Check for stored user session
    const storedUser = localStorage.getItem('smart-lib-user');
    if (storedUser) {
      const userData = JSON.parse(storedUser);
      setUser(userData);
      loadNotifications(userData.id);
    }
    setIsLoading(false);
  }, []);

  const loadNotifications = (userId: string) => {
    // Mock notifications - in real app, this would be an API call
    const mockNotifications: Notification[] = [
      {
        id: 'notif-1',
        userId,
        title: 'Booking Reminder',
        message: 'Your seat booking starts in 30 minutes',
        type: 'booking',
        isRead: false,
        createdAt: new Date().toISOString(),
        priority: 'high'
      },
      {
        id: 'notif-2',
        userId,
        title: 'Book Due Soon',
        message: 'Your reserved book expires tomorrow',
        type: 'reservation',
        isRead: false,
        createdAt: new Date(Date.now() - 3600000).toISOString(),
        priority: 'medium'
      }
    ];
    setNotifications(mockNotifications);
  };

  const login = async (crn: string, password: string): Promise<boolean> => {
    setIsLoading(true);
    try {
      // Enhanced authentication with approval check
      if (crn === 'admin' && password === 'admin') {
        const adminUser: User = {
          id: 'admin-1',
          crn: 'ADMIN001',
          name: 'Library Admin',
          email: 'admin@icap.edu.pk',
          role: 'admin',
          loyaltyPoints: 0,
          subscriptionPlan: 'premium_6month',
          isApproved: true,
          registrationDate: '2024-01-01',
          lastLogin: new Date().toISOString(),
          libraryAccess: ['lib-1', 'lib-2']
        };
        setUser(adminUser);
        localStorage.setItem('smart-lib-user', JSON.stringify(adminUser));
        loadNotifications(adminUser.id);
        return true;
      } else if (crn === 'superadmin' && password === 'superadmin') {
        const superAdminUser: User = {
          id: 'super-admin-1',
          crn: 'SUPERADMIN001',
          name: 'Super Administrator',
          email: 'superadmin@icap.edu.pk',
          role: 'super_admin',
          loyaltyPoints: 0,
          subscriptionPlan: 'premium_6month',
          isApproved: true,
          registrationDate: '2024-01-01',
          lastLogin: new Date().toISOString()
        };
        setUser(superAdminUser);
        localStorage.setItem('smart-lib-user', JSON.stringify(superAdminUser));
        loadNotifications(superAdminUser.id);
        return true;
      } else if (crn.startsWith('ICAP') && password === 'student') {
        const studentUser: User = {
          id: 'student-1',
          crn: crn,
          name: 'Ahmad Hassan',
          email: 'ahmad.hassan@icap.edu.pk',
          role: 'student',
          loyaltyPoints: 250,
          subscriptionPlan: 'premium_monthly',
          isApproved: true,
          registrationDate: '2024-01-15',
          lastLogin: new Date().toISOString()
        };
        setUser(studentUser);
        localStorage.setItem('smart-lib-user', JSON.stringify(studentUser));
        loadNotifications(studentUser.id);
        return true;
      }
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (userData: Partial<User> & { password: string }): Promise<boolean> => {
    setIsLoading(true);
    try {
      // Enhanced registration with approval workflow
      const newUser: User = {
        id: Date.now().toString(),
        crn: userData.crn || '',
        name: userData.name || '',
        email: userData.email || '',
        role: 'student',
        loyaltyPoints: 0,
        subscriptionPlan: 'free',
        isApproved: false, // Requires admin approval
        registrationDate: new Date().toISOString()
      };
      
      // In real app, this would send to admin for approval
      // For demo, we'll auto-approve
      newUser.isApproved = true;
      
      setUser(newUser);
      localStorage.setItem('smart-lib-user', JSON.stringify(newUser));
      loadNotifications(newUser.id);
      return true;
    } finally {
      setIsLoading(false);
    }
  };

  const updateUser = (userData: Partial<User>) => {
    if (user) {
      const updatedUser = { ...user, ...userData };
      setUser(updatedUser);
      localStorage.setItem('smart-lib-user', JSON.stringify(updatedUser));
    }
  };

  const markNotificationAsRead = (notificationId: string) => {
    setNotifications(prev => 
      prev.map(notif => 
        notif.id === notificationId ? { ...notif, isRead: true } : notif
      )
    );
  };

  const logout = () => {
    setUser(null);
    setNotifications([]);
    localStorage.removeItem('smart-lib-user');
  };

  const unreadCount = notifications.filter(n => !n.isRead).length;

  return (
    <AuthContext.Provider value={{ 
      user, 
      login, 
      register, 
      logout, 
      isLoading, 
      updateUser,
      notifications,
      markNotificationAsRead,
      unreadCount
    }}>
      {children}
    </AuthContext.Provider>
  );
};