import React, { useState } from 'react';
import { useApp } from '../../contexts/AppContext';
import { useAuth } from '../../contexts/AuthContext';
import { 
  MapPin, 
  Plus, 
  Edit3, 
  Trash2, 
  Users, 
  Clock,
  Wifi,
  Car,
  Coffee,
  BookOpen,
  Settings
} from 'lucide-react';

const LibraryManagement: React.FC = () => {
  const { libraries, addLibrary, updateLibrary } = useApp();
  const { user } = useAuth();
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingLibrary, setEditingLibrary] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    address: '',
    totalSeats: 100,
    openingHours: '8:00 AM - 10:00 PM',
    facilities: [] as string[],
    coordinates: { lat: 24.8607, lng: 67.0011 }
  });

  // Filter libraries based on admin access
  const accessibleLibraries = user?.role === 'super_admin' 
    ? libraries 
    : libraries.filter(lib => user?.libraryAccess?.includes(lib.id));

  const facilityOptions = [
    { id: 'wifi', label: 'WiFi', icon: Wifi },
    { id: 'ac', label: 'Air Conditioning', icon: Settings },
    { id: 'parking', label: 'Parking', icon: Car },
    { id: 'cafe', label: 'Cafe', icon: Coffee },
    { id: 'printing', label: 'Printing', icon: BookOpen },
    { id: 'study_rooms', label: 'Study Rooms', icon: Users },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (editingLibrary) {
      updateLibrary(editingLibrary, {
        ...formData,
        availableSeats: formData.totalSeats // Reset available seats when updating total
      });
      setEditingLibrary(null);
    } else {
      addLibrary({
        ...formData,
        availableSeats: formData.totalSeats,
        capacity: formData.totalSeats,
        currentOccupancy: 0,
        isActive: true
      });
    }
    
    setShowAddForm(false);
    resetForm();
  };

  const resetForm = () => {
    setFormData({
      name: '',
      address: '',
      totalSeats: 100,
      openingHours: '8:00 AM - 10:00 PM',
      facilities: [],
      coordinates: { lat: 24.8607, lng: 67.0011 }
    });
  };

  const handleEdit = (library: any) => {
    setFormData({
      name: library.name,
      address: library.address,
      totalSeats: library.totalSeats,
      openingHours: library.openingHours,
      facilities: library.facilities,
      coordinates: library.coordinates
    });
    setEditingLibrary(library.id);
    setShowAddForm(true);
  };

  const handleFacilityToggle = (facilityId: string) => {
    setFormData(prev => ({
      ...prev,
      facilities: prev.facilities.includes(facilityId)
        ? prev.facilities.filter(f => f !== facilityId)
        : [...prev.facilities, facilityId]
    }));
  };

  const getOccupancyColor = (occupancyRate: number) => {
    if (occupancyRate > 80) return 'text-red-600 bg-red-100';
    if (occupancyRate > 60) return 'text-orange-600 bg-orange-100';
    return 'text-green-600 bg-green-100';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-gray-800">Library Management</h2>
          <p className="text-gray-600 text-sm mt-1">
            {user?.role === 'super_admin' ? 'Manage all libraries' : 'Manage your assigned libraries'}
          </p>
        </div>
        
        {user?.role === 'super_admin' && (
          <button
            onClick={() => setShowAddForm(true)}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
          >
            <Plus className="w-4 h-4" />
            <span>Add Library</span>
          </button>
        )}
      </div>

      {/* Add/Edit Form */}
      {showAddForm && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">
            {editingLibrary ? 'Edit Library' : 'Add New Library'}
          </h3>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Library Name
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Total Seats
                </label>
                <input
                  type="number"
                  value={formData.totalSeats}
                  onChange={(e) => setFormData(prev => ({ ...prev, totalSeats: parseInt(e.target.value) }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                  min="1"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Address
              </label>
              <input
                type="text"
                value={formData.address}
                onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Opening Hours
              </label>
              <input
                type="text"
                value={formData.openingHours}
                onChange={(e) => setFormData(prev => ({ ...prev, openingHours: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="e.g., 8:00 AM - 10:00 PM"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Facilities
              </label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {facilityOptions.map((facility) => (
                  <label key={facility.id} className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.facilities.includes(facility.id)}
                      onChange={() => handleFacilityToggle(facility.id)}
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                    <facility.icon className="w-4 h-4 text-gray-600" />
                    <span className="text-sm text-gray-700">{facility.label}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="flex space-x-3 pt-4">
              <button
                type="submit"
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
              >
                {editingLibrary ? 'Update Library' : 'Add Library'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowAddForm(false);
                  setEditingLibrary(null);
                  resetForm();
                }}
                className="border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Libraries Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {accessibleLibraries.map((library) => {
          const occupancyRate = ((library.totalSeats - library.availableSeats) / library.totalSeats) * 100;
          
          return (
            <div key={library.id} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="font-semibold text-gray-800">{library.name}</h3>
                  <div className="flex items-center text-gray-600 text-sm mt-1">
                    <MapPin className="w-4 h-4 mr-1" />
                    {library.address}
                  </div>
                </div>
                
                {user?.role === 'super_admin' && (
                  <div className="flex space-x-1">
                    <button
                      onClick={() => handleEdit(library)}
                      className="p-1 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button className="p-1 text-gray-600 hover:text-red-600 hover:bg-red-50 rounded">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>

              {/* Stats */}
              <div className="space-y-3 mb-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Occupancy</span>
                  <span className={`text-xs font-medium px-2 py-1 rounded-full ${getOccupancyColor(occupancyRate)}`}>
                    {Math.round(occupancyRate)}%
                  </span>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Available Seats</span>
                  <span className="text-sm font-medium text-gray-800">
                    {library.availableSeats} / {library.totalSeats}
                  </span>
                </div>

                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full transition-all duration-300 ${
                      occupancyRate > 80 ? 'bg-red-500' :
                      occupancyRate > 60 ? 'bg-orange-500' : 'bg-green-500'
                    }`}
                    style={{ width: `${occupancyRate}%` }}
                  ></div>
                </div>
              </div>

              {/* Opening Hours */}
              <div className="flex items-center text-gray-600 text-sm mb-4">
                <Clock className="w-4 h-4 mr-1" />
                {library.openingHours}
              </div>

              {/* Facilities */}
              <div className="mb-4">
                <div className="flex flex-wrap gap-1">
                  {library.facilities.slice(0, 3).map(facility => (
                    <span key={facility} className="bg-gray-100 text-gray-700 text-xs px-2 py-1 rounded-full">
                      {facility}
                    </span>
                  ))}
                  {library.facilities.length > 3 && (
                    <span className="text-xs text-gray-500 px-2 py-1">
                      +{library.facilities.length - 3} more
                    </span>
                  )}
                </div>
              </div>

              {/* Actions */}
              <div className="flex space-x-2">
                <button className="flex-1 bg-blue-600 text-white py-2 px-3 rounded-lg hover:bg-blue-700 transition-colors text-sm">
                  View Details
                </button>
                <button className="flex-1 border border-gray-300 text-gray-700 py-2 px-3 rounded-lg hover:bg-gray-50 transition-colors text-sm">
                  Manage Seats
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {accessibleLibraries.length === 0 && (
        <div className="text-center py-12">
          <MapPin className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-800 mb-2">No libraries found</h3>
          <p className="text-gray-600">
            {user?.role === 'super_admin' 
              ? 'Add your first library to get started' 
              : 'No libraries assigned to you'}
          </p>
        </div>
      )}
    </div>
  );
};

export default LibraryManagement;