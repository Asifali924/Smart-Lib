import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { 
  Users, 
  Search, 
  Filter, 
  CheckCircle, 
  XCircle, 
  Clock,
  Mail,
  User,
  Shield,
  Award
} from 'lucide-react';

interface MockUser {
  id: string;
  crn: string;
  name: string;
  email: string;
  role: 'student' | 'admin';
  isApproved: boolean;
  registrationDate: string;
  lastLogin?: string;
  loyaltyPoints: number;
  subscriptionPlan: string;
  totalBookings: number;
  status: 'active' | 'pending' | 'suspended';
}

const UserManagement: React.FC = () => {
  const { user: currentUser } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'active' | 'suspended'>('all');
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);

  // Mock users data - in real app, this would come from API
  const [users, setUsers] = useState<MockUser[]>([
    {
      id: 'user-1',
      crn: 'ICAP2024001',
      name: 'Ahmad Hassan',
      email: 'ahmad.hassan@icap.edu.pk',
      role: 'student',
      isApproved: true,
      registrationDate: '2024-01-15',
      lastLogin: '2024-02-10T10:30:00Z',
      loyaltyPoints: 250,
      subscriptionPlan: 'premium_monthly',
      totalBookings: 15,
      status: 'active'
    },
    {
      id: 'user-2',
      crn: 'ICAP2024002',
      name: 'Fatima Ali',
      email: 'fatima.ali@icap.edu.pk',
      role: 'student',
      isApproved: false,
      registrationDate: '2024-02-08',
      loyaltyPoints: 0,
      subscriptionPlan: 'free',
      totalBookings: 0,
      status: 'pending'
    },
    {
      id: 'user-3',
      crn: 'ICAP2024003',
      name: 'Muhammad Usman',
      email: 'muhammad.usman@icap.edu.pk',
      role: 'student',
      isApproved: true,
      registrationDate: '2024-01-20',
      lastLogin: '2024-02-09T15:45:00Z',
      loyaltyPoints: 180,
      subscriptionPlan: 'free',
      totalBookings: 8,
      status: 'active'
    },
    {
      id: 'user-4',
      crn: 'ICAP2024004',
      name: 'Sarah Khan',
      email: 'sarah.khan@icap.edu.pk',
      role: 'student',
      isApproved: true,
      registrationDate: '2024-01-25',
      lastLogin: '2024-02-05T09:20:00Z',
      loyaltyPoints: 95,
      subscriptionPlan: 'premium_6month',
      totalBookings: 22,
      status: 'suspended'
    }
  ]);

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         user.crn.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || user.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleApproveUser = (userId: string) => {
    setUsers(prev => prev.map(user => 
      user.id === userId 
        ? { ...user, isApproved: true, status: 'active' as const }
        : user
    ));
  };

  const handleRejectUser = (userId: string) => {
    setUsers(prev => prev.filter(user => user.id !== userId));
  };

  const handleSuspendUser = (userId: string) => {
    setUsers(prev => prev.map(user => 
      user.id === userId 
        ? { ...user, status: 'suspended' as const }
        : user
    ));
  };

  const handleActivateUser = (userId: string) => {
    setUsers(prev => prev.map(user => 
      user.id === userId 
        ? { ...user, status: 'active' as const }
        : user
    ));
  };

  const handleSelectUser = (userId: string) => {
    setSelectedUsers(prev => 
      prev.includes(userId) 
        ? prev.filter(id => id !== userId)
        : [...prev, userId]
    );
  };

  const handleBulkAction = (action: 'approve' | 'suspend' | 'delete') => {
    selectedUsers.forEach(userId => {
      switch (action) {
        case 'approve':
          handleApproveUser(userId);
          break;
        case 'suspend':
          handleSuspendUser(userId);
          break;
        case 'delete':
          handleRejectUser(userId);
          break;
      }
    });
    setSelectedUsers([]);
  };

  const getStatusBadge = (status: string, isApproved: boolean) => {
    if (!isApproved) {
      return <span className="px-2 py-1 text-xs font-medium bg-orange-100 text-orange-800 rounded-full">Pending</span>;
    }
    
    switch (status) {
      case 'active':
        return <span className="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">Active</span>;
      case 'suspended':
        return <span className="px-2 py-1 text-xs font-medium bg-red-100 text-red-800 rounded-full">Suspended</span>;
      default:
        return <span className="px-2 py-1 text-xs font-medium bg-gray-100 text-gray-800 rounded-full">Unknown</span>;
    }
  };

  const stats = [
    {
      title: 'Total Users',
      value: users.length,
      icon: Users,
      color: 'blue'
    },
    {
      title: 'Pending Approval',
      value: users.filter(u => !u.isApproved).length,
      icon: Clock,
      color: 'orange'
    },
    {
      title: 'Active Users',
      value: users.filter(u => u.status === 'active').length,
      icon: CheckCircle,
      color: 'green'
    },
    {
      title: 'Suspended',
      value: users.filter(u => u.status === 'suspended').length,
      icon: XCircle,
      color: 'red'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">{stat.title}</p>
                <p className="text-2xl font-bold text-gray-800">{stat.value}</p>
              </div>
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                stat.color === 'blue' ? 'bg-blue-100 text-blue-600' :
                stat.color === 'orange' ? 'bg-orange-100 text-orange-600' :
                stat.color === 'green' ? 'bg-green-100 text-green-600' :
                'bg-red-100 text-red-600'
              }`}>
                <stat.icon className="w-5 h-5" />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search users by name, CRN, or email..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          
          <div className="flex gap-3">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">All Status</option>
              <option value="pending">Pending</option>
              <option value="active">Active</option>
              <option value="suspended">Suspended</option>
            </select>

            {selectedUsers.length > 0 && (
              <div className="flex gap-2">
                <button
                  onClick={() => handleBulkAction('approve')}
                  className="px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 text-sm"
                >
                  Approve ({selectedUsers.length})
                </button>
                <button
                  onClick={() => handleBulkAction('suspend')}
                  className="px-3 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 text-sm"
                >
                  Suspend
                </button>
                <button
                  onClick={() => handleBulkAction('delete')}
                  className="px-3 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 text-sm"
                >
                  Delete
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Users Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left">
                  <input
                    type="checkbox"
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSelectedUsers(filteredUsers.map(u => u.id));
                      } else {
                        setSelectedUsers([]);
                      }
                    }}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  User
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Subscription
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Activity
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredUsers.map((user) => (
                <tr key={user.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <input
                      type="checkbox"
                      checked={selectedUsers.includes(user.id)}
                      onChange={() => handleSelectUser(user.id)}
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center mr-3">
                        <User className="w-5 h-5 text-gray-600" />
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-800">{user.name}</div>
                        <div className="text-sm text-gray-500">{user.crn}</div>
                        <div className="text-xs text-gray-400">{user.email}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    {getStatusBadge(user.status, user.isApproved)}
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-gray-800 capitalize">
                      {user.subscriptionPlan.replace('_', ' ')}
                    </div>
                    <div className="text-xs text-gray-500 flex items-center mt-1">
                      <Award className="w-3 h-3 mr-1" />
                      {user.loyaltyPoints} points
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-gray-800">{user.totalBookings} bookings</div>
                    <div className="text-xs text-gray-500">
                      {user.lastLogin ? `Last: ${new Date(user.lastLogin).toLocaleDateString()}` : 'Never'}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex space-x-2">
                      {!user.isApproved && (
                        <>
                          <button
                            onClick={() => handleApproveUser(user.id)}
                            className="text-green-600 hover:text-green-700 text-sm font-medium"
                          >
                            Approve
                          </button>
                          <button
                            onClick={() => handleRejectUser(user.id)}
                            className="text-red-600 hover:text-red-700 text-sm font-medium"
                          >
                            Reject
                          </button>
                        </>
                      )}
                      
                      {user.isApproved && user.status === 'active' && (
                        <button
                          onClick={() => handleSuspendUser(user.id)}
                          className="text-orange-600 hover:text-orange-700 text-sm font-medium"
                        >
                          Suspend
                        </button>
                      )}
                      
                      {user.status === 'suspended' && (
                        <button
                          onClick={() => handleActivateUser(user.id)}
                          className="text-green-600 hover:text-green-700 text-sm font-medium"
                        >
                          Activate
                        </button>
                      )}
                      
                      <button className="text-blue-600 hover:text-blue-700 text-sm font-medium">
                        View
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {filteredUsers.length === 0 && (
        <div className="text-center py-12">
          <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-800 mb-2">No users found</h3>
          <p className="text-gray-600">Try adjusting your search or filters</p>
        </div>
      )}
    </div>
  );
};

export default UserManagement;