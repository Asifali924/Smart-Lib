import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { useApp } from '../../contexts/AppContext';
import { 
  BarChart3, 
  Clock, 
  Calendar,
  Target,
  TrendingUp,
  BookOpen,
  Award,
  Brain,
  Zap,
  Users
} from 'lucide-react';

const StudyAnalytics: React.FC = () => {
  const { user } = useAuth();
  const { bookings } = useApp();
  const [timeRange, setTimeRange] = useState<'week' | 'month' | 'year'>('month');

  // Mock study data - in real app, this would come from API
  const studyStats = {
    totalHours: 156,
    averageSession: 2.5,
    longestSession: 6.5,
    studyStreak: 12,
    productivity: 85,
    focusScore: 78,
    completedGoals: 23,
    totalGoals: 30
  };

  const weeklyData = [
    { day: 'Mon', hours: 4.5, sessions: 2, productivity: 85 },
    { day: 'Tue', hours: 3.2, sessions: 2, productivity: 78 },
    { day: 'Wed', hours: 5.1, sessions: 3, productivity: 92 },
    { day: 'Thu', hours: 2.8, sessions: 1, productivity: 70 },
    { day: 'Fri', hours: 6.2, sessions: 3, productivity: 88 },
    { day: 'Sat', hours: 4.0, sessions: 2, productivity: 82 },
    { day: 'Sun', hours: 3.5, sessions: 2, productivity: 75 }
  ];

  const subjectBreakdown = [
    { subject: 'Financial Accounting', hours: 45, percentage: 29, color: 'bg-blue-500' },
    { subject: 'Auditing', hours: 38, percentage: 24, color: 'bg-green-500' },
    { subject: 'Taxation', hours: 32, percentage: 21, color: 'bg-orange-500' },
    { subject: 'Corporate Law', hours: 25, percentage: 16, color: 'bg-purple-500' },
    { subject: 'Business Ethics', hours: 16, percentage: 10, color: 'bg-teal-500' }
  ];

  const studyGoals = [
    {
      id: 'daily_hours',
      title: 'Study 4 hours daily',
      progress: 75,
      target: 4,
      current: 3,
      unit: 'hours',
      status: 'on_track'
    },
    {
      id: 'weekly_sessions',
      title: 'Complete 15 sessions weekly',
      progress: 87,
      target: 15,
      current: 13,
      unit: 'sessions',
      status: 'ahead'
    },
    {
      id: 'book_chapters',
      title: 'Read 20 chapters this month',
      progress: 60,
      target: 20,
      current: 12,
      unit: 'chapters',
      status: 'behind'
    }
  ];

  const achievements = [
    {
      title: 'Study Warrior',
      description: 'Studied for 7 consecutive days',
      icon: Target,
      unlocked: true,
      date: '2024-02-08'
    },
    {
      title: 'Focus Master',
      description: 'Maintained 90%+ focus for 5 sessions',
      icon: Brain,
      unlocked: true,
      date: '2024-02-05'
    },
    {
      title: 'Marathon Learner',
      description: 'Single session over 6 hours',
      icon: Clock,
      unlocked: false,
      progress: 85
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'ahead': return 'text-green-600 bg-green-100';
      case 'on_track': return 'text-blue-600 bg-blue-100';
      case 'behind': return 'text-orange-600 bg-orange-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header with Time Range Selector */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-gray-800">Study Analytics</h2>
          <p className="text-gray-600 text-sm mt-1">Track your learning progress and productivity</p>
        </div>
        <select
          value={timeRange}
          onChange={(e) => setTimeRange(e.target.value as any)}
          className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        >
          <option value="week">This Week</option>
          <option value="month">This Month</option>
          <option value="year">This Year</option>
        </select>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm font-medium">Total Study Hours</p>
              <p className="text-2xl font-bold text-gray-800 mt-1">{studyStats.totalHours}h</p>
              <p className="text-green-600 text-xs mt-1">+12h vs last month</p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Clock className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm font-medium">Study Streak</p>
              <p className="text-2xl font-bold text-gray-800 mt-1">{studyStats.studyStreak} days</p>
              <p className="text-blue-600 text-xs mt-1">Personal best!</p>
            </div>
            <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
              <Target className="w-6 h-6 text-orange-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm font-medium">Productivity Score</p>
              <p className="text-2xl font-bold text-gray-800 mt-1">{studyStats.productivity}%</p>
              <p className="text-green-600 text-xs mt-1">+5% improvement</p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm font-medium">Focus Score</p>
              <p className="text-2xl font-bold text-gray-800 mt-1">{studyStats.focusScore}%</p>
              <p className="text-orange-600 text-xs mt-1">Room for improvement</p>
            </div>
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
              <Brain className="w-6 h-6 text-purple-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Weekly Study Pattern */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Weekly Study Pattern</h3>
        <div className="space-y-4">
          {weeklyData.map((day, index) => (
            <div key={index} className="flex items-center justify-between">
              <div className="flex items-center space-x-3 w-20">
                <span className="text-sm font-medium text-gray-700">{day.day}</span>
              </div>
              <div className="flex-1 mx-4">
                <div className="flex items-center space-x-2">
                  <div className="w-32 bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-blue-600 h-2 rounded-full"
                      style={{ width: `${(day.hours / 8) * 100}%` }}
                    ></div>
                  </div>
                  <span className="text-sm text-gray-600 w-12">{day.hours}h</span>
                </div>
              </div>
              <div className="flex items-center space-x-4 text-sm text-gray-600">
                <span>{day.sessions} sessions</span>
                <span className={`px-2 py-1 rounded-full text-xs ${
                  day.productivity >= 85 ? 'bg-green-100 text-green-600' :
                  day.productivity >= 75 ? 'bg-blue-100 text-blue-600' :
                  'bg-orange-100 text-orange-600'
                }`}>
                  {day.productivity}%
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Subject Breakdown */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Subject Breakdown</h3>
        <div className="space-y-4">
          {subjectBreakdown.map((subject, index) => (
            <div key={index} className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className={`w-4 h-4 rounded ${subject.color}`}></div>
                <span className="text-sm font-medium text-gray-700">{subject.subject}</span>
              </div>
              <div className="flex items-center space-x-4">
                <div className="w-32 bg-gray-200 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full ${subject.color}`}
                    style={{ width: `${subject.percentage}%` }}
                  ></div>
                </div>
                <span className="text-sm text-gray-600 w-12">{subject.hours}h</span>
                <span className="text-sm text-gray-500 w-8">{subject.percentage}%</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Study Goals */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Study Goals</h3>
        <div className="space-y-4">
          {studyGoals.map((goal) => (
            <div key={goal.id} className="p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-medium text-gray-800">{goal.title}</h4>
                <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(goal.status)}`}>
                  {goal.status.replace('_', ' ')}
                </span>
              </div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">
                  {goal.current} / {goal.target} {goal.unit}
                </span>
                <span className="text-sm font-medium text-gray-800">{goal.progress}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className={`h-2 rounded-full ${
                    goal.status === 'ahead' ? 'bg-green-500' :
                    goal.status === 'on_track' ? 'bg-blue-500' :
                    'bg-orange-500'
                  }`}
                  style={{ width: `${goal.progress}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Study Achievements */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Study Achievements</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {achievements.map((achievement, index) => (
            <div
              key={index}
              className={`p-4 rounded-lg border ${
                achievement.unlocked
                  ? 'border-green-300 bg-green-50'
                  : 'border-gray-200 bg-gray-50'
              }`}
            >
              <div className="text-center">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3 ${
                  achievement.unlocked ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-400'
                }`}>
                  <achievement.icon className="w-6 h-6" />
                </div>
                <h4 className="font-medium text-gray-800 mb-1">{achievement.title}</h4>
                <p className="text-sm text-gray-600 mb-2">{achievement.description}</p>
                {achievement.unlocked ? (
                  <span className="text-xs text-green-600">
                    Unlocked on {achievement.date}
                  </span>
                ) : (
                  <div>
                    <div className="w-full bg-gray-200 rounded-full h-1 mb-1">
                      <div
                        className="bg-blue-600 h-1 rounded-full"
                        style={{ width: `${achievement.progress}%` }}
                      ></div>
                    </div>
                    <span className="text-xs text-gray-500">{achievement.progress}% complete</span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Study Recommendations */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl text-white p-6">
        <div className="flex items-center mb-4">
          <Zap className="w-6 h-6 mr-2" />
          <h3 className="text-lg font-semibold">AI Study Recommendations</h3>
        </div>
        <div className="space-y-3">
          <div className="bg-white bg-opacity-20 rounded-lg p-3">
            <h4 className="font-medium mb-1">Optimize Your Study Schedule</h4>
            <p className="text-sm text-blue-100">
              Your productivity peaks between 2-4 PM. Consider scheduling important topics during this time.
            </p>
          </div>
          <div className="bg-white bg-opacity-20 rounded-lg p-3">
            <h4 className="font-medium mb-1">Focus Improvement</h4>
            <p className="text-sm text-blue-100">
              Try the Pomodoro technique (25 min study + 5 min break) to improve your focus score.
            </p>
          </div>
          <div className="bg-white bg-opacity-20 rounded-lg p-3">
            <h4 className="font-medium mb-1">Subject Balance</h4>
            <p className="text-sm text-blue-100">
              Increase time on Business Ethics to maintain balanced preparation across all subjects.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudyAnalytics;